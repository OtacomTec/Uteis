/*
 * ADD SUPPORT FOR HTML5 ELEMENTS IN IE8 AND OLDER
 */

document.createElement('article'); 
document.createElement('aside'); 
document.createElement('details'); 
document.createElement('figcaption');
document.createElement('figure');
document.createElement('footer'); 
document.createElement('header'); 
document.createElement('hgroup'); 
document.createElement('main');
document.createElement('menu'); 
document.createElement('nav'); 
document.createElement('section');
